function getRandomSentence () {
    var index= Math.floor(Math.random() * (sentences.length));
    return sentences[index];
} 

var sentences = [
    'I will go and do the things which the Lord hath commanded, for I know that the Lord giveth no commandments unto the children of men, save he shall prepare a way for them that they may accomplish the thing which he commandeth them.',
    'Adam fell that men might be; and men are, that they might have joy.',
    'ye must press forward with a steadfastness in Christ, having a perfect brightness of hope, and a love of God and of all men.',
    'if ye do not watch yourselves, and your thoughts, and your words, and your deeds, and observe the commandments of God, and continue in the faith of what ye have heard concerning the coming of our Lord, even unto the end of your lives, ye must perish.',
    '... when ye are in the service of your fellow beings ye are only in the service of your God'
];

function sentence() {
    var content = getRandomSentence()
    document.getElementById('sentence').innerHTML = "&quot;" + content + "&quot;";
}
